/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.ArrayList;
import java.util.List;

public class GestorCredenciales {
    private static GestorCredenciales instancia;
    private List<Credencial> lista;

    private GestorCredenciales() {
        lista = new ArrayList<>();
    }

    public static GestorCredenciales getInstancia() {
        if (instancia == null) {
            instancia = new GestorCredenciales();
        }
        return instancia;
    }

    public void agregarCredencial(Credencial c) {
        lista.add(c);
    }

    public void listarCredenciales() {
        if (lista.isEmpty()) {
            System.out.println("No hay credenciales registradas.");
        } else {
            for (int i = 0; i < lista.size(); i++) {
                System.out.println((i + 1) + ". " + lista.get(i));
            }
        }
    }
}

