/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author davic
 */
public class Credencial {
    private String Nombre;
    private String Cargo;
    private String Rut;

    public Credencial() {
    }

    public Credencial(String Nombre, String Cargo, String Rut) {
        this.Nombre = Nombre;
        this.Cargo = Cargo;
        this.Rut = Rut;
    }
    public Credencial clonar(){
        return new Credencial(Nombre,Cargo,Rut);
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getCargo() {
        return Cargo;
    }

    public void setCargo(String Cargo) {
        this.Cargo = Cargo;
    }

    public String getRut() {
        return Rut;
    }

    public void setRut(String Rut) {
        this.Rut = Rut;
    }
    @Override
    public String toString() {
        return "Credencial [Nombre: " + Nombre + ", Cargo: " + Cargo + ", RUT: " + Rut + "]";
    }
}
