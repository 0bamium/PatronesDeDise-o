/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package app;

import model.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner oScanner = new Scanner(System.in);
        GestorCredenciales gestor = GestorCredenciales.getInstancia();
        
        Credencial plantillaBase = new Credencial("Nombre", "Cargo", "RUT"); 

        int opcion;
        do {
            System.out.println("--- Menu ---");
            System.out.println("1. Crear nueva credencial");
            System.out.println("2. Ver credenciales");
            System.out.println("3. Salir");
            System.out.print("Elige una opcion: ");
            opcion = oScanner.nextInt();
            oScanner.nextLine();

            switch (opcion) {
                case 1:
                    
                    Credencial nueva = plantillaBase.clonar();
                    
                    System.out.print("Nombre: ");
                    nueva.setNombre(oScanner.nextLine());

                    System.out.print("Cargo: ");
                    nueva.setCargo(oScanner.nextLine());

                    System.out.print("RUT: ");
                    nueva.setRut(oScanner.nextLine());

                    gestor.agregarCredencial(nueva);
                    System.out.println("✅ Credencial creada correctamente.");
                    break;
                case 2:
                    gestor.listarCredenciales();
                    break;
                case 3:
                    System.out.println("👋 Saliendo...");
                    break;
                default:
                    System.out.println("❌ Opción no válida.");
            }
        } while (opcion != 3);
        
        oScanner.close();
    }
}

